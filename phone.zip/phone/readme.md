# eCommerce Website Template

## Setup

#### Download [Node.js](https://nodejs.org/en/). Run the following commands:

```
# Install dependencies (Only for first time).
npm i

# Start server on localhost:3000
gulp watch

# Build for production in dist/ directory
- gulp style
- gulp javascript
- gulp images
- gulp images1
- gulp images2
- gulp images3
```
